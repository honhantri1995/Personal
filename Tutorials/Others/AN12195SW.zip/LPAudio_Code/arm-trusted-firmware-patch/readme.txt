Patch created based on commit c435bc217ba1435285ec245fb213d3c4e46e0eb7

commit c435bc217ba1435285ec245fb213d3c4e46e0eb7
Author: Anson Huang <Anson.Huang@nxp.com>
Date:   Sun Apr 15 16:44:27 2018 +0800

    imx8qm/imx8qxp: make sure psci_affinity_info returns correct value

    psci_affinity_info could be called from kernel any time,
    but the cpu_kill function could return incorrect value
    if psci_affinity_info is NOT called during cpu hot-plug
    procedure, so the cpu_kill function should NOT over-write
    the return value called from CPU internal affinity info.

    Signed-off-by: Anson Huang <Anson.Huang@nxp.com>